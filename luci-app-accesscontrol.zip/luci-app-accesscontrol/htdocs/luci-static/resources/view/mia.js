'use strict';
'require view';
'require dom';
'require poll';
'require uci';
'require rpc';
'require form';

/*
 * Query the init script state of the "mia" service. Requires the
 * init script to register a procd instance while the firewall
 * rules are active.
 */
const callServiceList = rpc.declare({
	object: 'service',
	method: 'list',
	params: ['name'],
	expect: { '': {} }
});

function getServiceStatus() {
	return L.resolveDefault(callServiceList('mia'))
		.then(function (res) {
			let is_running = false;
			try {
				is_running = res.mia.instances.instance1.running;
			} catch (e) { }
			return is_running;
		});
}

function miaServiceStatus() {
	return Promise.all([
		getServiceStatus()
	]);
}

/*
 * Query known MAC address / hostname pairs, replaces the old
 * luci.sys.net.mac_hints() call used by the Lua CBI model.
 */
var callHostHints = rpc.declare({
	object: 'luci-rpc',
	method: 'getHostHints',
	expect: { '': {} }
});

function validateTime(section_id, value) {
	if (value == null || value == '')
		return _('Expecting a time in the format HH:MM');

	var m = value.match(/^(\d{1,2}):(\d{2})$/),
	    h = m ? +m[1] : -1,
	    min = m ? +m[2] : -1;

	if (h < 0 || h > 23 || min < 0 || min > 59)
		return _('Expecting a time in the format HH:MM');

	return true;
}

return view.extend({
	load: function() {
		return Promise.all([
			L.resolveDefault(callHostHints(), {}),
			uci.load('mia')
		]);
	},

	render: function(data) {
		var hostHints = data[0] || {},
		    m, s, o, statusEl;

		m = new form.Map('mia',
			_('Internet Access Schedule Control'),
			_('Access Schedule Control Settings'));

		/*
		 * Basic settings
		 */
		s = m.section(form.TypedSection, 'basic', _('General Settings'));
		s.anonymous = true;
		s.addremove = false;

		o = s.option(form.Flag, 'enable', _('Enabled'));
		o.rmempty = false;

		o = s.option(form.Flag, 'strict', _('Strict Mode'),
			_('Strict Mode will degrade CPU performance, but it can achieve better results'));
		o.rmempty = false;

		/*
		 * Client rules table
		 */
		s = m.section(form.TableSection, 'macbind', _('Client Rules'));
		s.anonymous = true;
		s.addremove = true;
		s.sortable = false;

		o = s.option(form.Flag, 'enable', _('Enabled'));
		o.default = '1';
		o.rmempty = false;

		o = s.option(form.Value, 'macaddr', _('MAC address (Computer Name)'));
		o.rmempty = true;

		Object.keys(hostHints).sort().forEach(function(mac) {
			var hint = hostHints[mac],
			    name = (hint && hint.name) ? hint.name : (hint && hint.ipaddrs) ? hint.ipaddrs[0] : null;

			o.value(mac, name ? '%s (%s)'.format(mac, name) : mac);
		});

		o = s.option(form.Value, 'timeon', _('Start time'));
		o.default = '00:00';
		o.rmempty = false;
		o.validate = validateTime;

		o = s.option(form.Value, 'timeoff', _('End time'));
		o.default = '23:59';
		o.rmempty = false;
		o.validate = validateTime;

		o = s.option(form.Flag, 'z1', _('Mon'));
		o.default = '1';

		o = s.option(form.Flag, 'z2', _('Tue'));
		o.default = '1';

		o = s.option(form.Flag, 'z3', _('Wed'));
		o.default = '1';

		o = s.option(form.Flag, 'z4', _('Thu'));
		o.default = '1';

		o = s.option(form.Flag, 'z5', _('Fri'));
		o.default = '1';

		o = s.option(form.Flag, 'z6', _('Sat'));
		o.default = '1';

		o = s.option(form.Flag, 'z7', _('Sun'));
		o.default = '1';

		return m.render().then(function(mapEl) {
			statusEl = E('p', { 'id': 'mia_status', 'class': 'alert-message' }, [
				E('em', [ _('Collecting data…') ])
			]);

			var descr = mapEl.querySelector('.cbi-map-descr');
			if (descr)
				descr.parentNode.insertBefore(statusEl, descr.nextSibling);
			else
				mapEl.insertBefore(statusEl, mapEl.firstChild);

			poll.add(L.bind(function() {
				return L.resolveDefault(getServiceStatus()).then(function(running) {
					dom.content(statusEl, [
						E('span', {
							'style': (running ? 'color:#3a3' : 'color:#c33')
						}, [ running
							? _('Internet Access Schedule Control: RUNNING')
							: _('Internet Access Schedule Control: NOT RUNNING')
						])
					]);
				});
			}, this), 5);

			return mapEl;
		});
	}
});

